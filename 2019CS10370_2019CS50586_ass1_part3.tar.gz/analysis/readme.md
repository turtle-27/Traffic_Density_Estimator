# This folder contains: 
    - output files generated containing data for different methods.
    - pyhton script "plotting.py" for plotting graphs. 
    - graphs for different methods.
    - report for the assignment.

# Terminal commands to:
## 1. To plot and save graphs  
    - running "python3 plotting.py" on termial will show the output graphs and also save them in the working directory.

